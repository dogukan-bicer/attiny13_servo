/*
 * ArduinoCore.cpp
 *
 * Created: 5.07.2021 14:50:20
 * Author : dogukan
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

